package ua.spro.model.user;

public enum UserState {
    NOT_ENTERED, ENTERED, CREATING_NEW, EDITING
}
