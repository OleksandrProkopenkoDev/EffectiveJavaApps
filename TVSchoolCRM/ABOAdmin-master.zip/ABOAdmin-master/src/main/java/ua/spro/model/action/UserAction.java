package ua.spro.model.action;

public interface UserAction {

    String getDescription();
}
