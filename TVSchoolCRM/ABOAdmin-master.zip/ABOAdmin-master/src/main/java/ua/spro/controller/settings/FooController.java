package ua.spro.controller.settings;

public class FooController {
}
